/*
  # Artfulness E-commerce Marketplace Schema

  ## Overview
  This migration creates a complete e-commerce marketplace for Artfulness, enabling artists 
  to list and sell art pieces with commission tracking for the platform.

  ## New Tables

  ### 1. `profiles`
  Extended user profiles linked to auth.users
  - `id` (uuid, FK to auth.users) - User ID
  - `email` (text) - User email
  - `display_name` (text) - Public display name
  - `avatar_url` (text) - Profile picture URL
  - `bio` (text) - User biography
  - `created_at` (timestamptz) - Account creation time
  - `updated_at` (timestamptz) - Last update time

  ### 2. `artists`
  Artist-specific profiles for sellers
  - `id` (uuid, PK) - Artist ID
  - `user_id` (uuid, FK to profiles) - Linked user account
  - `artist_name` (text) - Public artist name
  - `story` (text) - Artist's story and mission
  - `mental_health_focus` (text) - Mental health cause/focus area
  - `commission_rate` (numeric) - Artfulness commission percentage (default 15%)
  - `total_sales` (numeric) - Lifetime sales total
  - `total_commissions_paid` (numeric) - Total commissions paid to Artfulness
  - `is_approved` (boolean) - Whether artist is approved to sell
  - `created_at` (timestamptz) - Artist registration date
  - `updated_at` (timestamptz) - Last update time

  ### 3. `products`
  Art pieces listed for sale
  - `id` (uuid, PK) - Product ID
  - `artist_id` (uuid, FK to artists) - Artist who created/listed the piece
  - `title` (text) - Artwork title
  - `description` (text) - Detailed description
  - `price` (numeric) - Sale price in USD
  - `image_url` (text) - Primary image URL
  - `image_urls` (text[]) - Additional image URLs
  - `category` (text) - Art category (painting, sculpture, digital, etc.)
  - `dimensions` (text) - Physical dimensions if applicable
  - `medium` (text) - Art medium (oil, acrylic, digital, etc.)
  - `stock_quantity` (integer) - Available quantity (1 for unique pieces)
  - `is_active` (boolean) - Whether product is currently listed
  - `created_at` (timestamptz) - Listing creation date
  - `updated_at` (timestamptz) - Last update time

  ### 4. `cart_items`
  Shopping cart items for users
  - `id` (uuid, PK) - Cart item ID
  - `user_id` (uuid, FK to profiles) - User who added item
  - `product_id` (uuid, FK to products) - Product in cart
  - `quantity` (integer) - Quantity (usually 1 for art)
  - `created_at` (timestamptz) - When added to cart

  ### 5. `orders`
  Purchase orders
  - `id` (uuid, PK) - Order ID
  - `user_id` (uuid, FK to profiles) - Buyer
  - `total_amount` (numeric) - Total order amount
  - `status` (text) - Order status (pending, completed, cancelled)
  - `shipping_address` (jsonb) - Shipping address details
  - `created_at` (timestamptz) - Order creation time
  - `updated_at` (timestamptz) - Last status update

  ### 6. `order_items`
  Individual items in orders
  - `id` (uuid, PK) - Order item ID
  - `order_id` (uuid, FK to orders) - Parent order
  - `product_id` (uuid, FK to products) - Product purchased
  - `artist_id` (uuid, FK to artists) - Artist who created the piece
  - `quantity` (integer) - Quantity purchased
  - `price_at_purchase` (numeric) - Price at time of purchase
  - `commission_rate` (numeric) - Commission rate at time of purchase
  - `commission_amount` (numeric) - Commission amount for Artfulness
  - `artist_amount` (numeric) - Amount going to artist

  ### 7. `commissions`
  Commission tracking and payouts
  - `id` (uuid, PK) - Commission ID
  - `artist_id` (uuid, FK to artists) - Artist receiving commission
  - `order_item_id` (uuid, FK to order_items) - Related order item
  - `amount` (numeric) - Commission amount to Artfulness
  - `artist_amount` (numeric) - Amount for artist
  - `status` (text) - Payment status (pending, paid)
  - `created_at` (timestamptz) - Commission creation date
  - `paid_at` (timestamptz) - When commission was paid

  ## Security
  Row Level Security (RLS) is enabled on all tables with appropriate policies for:
  - Public read access to active products and artist profiles
  - Users can manage their own profiles, cart items, and orders
  - Artists can manage their own products and view their sales
  - Authenticated users can create orders and add items to cart
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  display_name text,
  avatar_url text,
  bio text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Artists table
CREATE TABLE IF NOT EXISTS artists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL UNIQUE,
  artist_name text NOT NULL,
  story text,
  mental_health_focus text,
  commission_rate numeric DEFAULT 15.0 CHECK (commission_rate >= 0 AND commission_rate <= 100),
  total_sales numeric DEFAULT 0,
  total_commissions_paid numeric DEFAULT 0,
  is_approved boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE artists ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view approved artists"
  ON artists FOR SELECT
  TO authenticated
  USING (is_approved = true);

CREATE POLICY "Users can view their own artist profile"
  ON artists FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their artist profile"
  ON artists FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own artist profile"
  ON artists FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id uuid REFERENCES artists(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text,
  price numeric NOT NULL CHECK (price > 0),
  image_url text,
  image_urls text[] DEFAULT ARRAY[]::text[],
  category text,
  dimensions text,
  medium text,
  stock_quantity integer DEFAULT 1 CHECK (stock_quantity >= 0),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active products"
  ON products FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Artists can view their own products"
  ON products FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM artists
      WHERE artists.id = products.artist_id
      AND artists.user_id = auth.uid()
    )
  );

CREATE POLICY "Artists can create products"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM artists
      WHERE artists.id = products.artist_id
      AND artists.user_id = auth.uid()
    )
  );

CREATE POLICY "Artists can update their own products"
  ON products FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM artists
      WHERE artists.id = products.artist_id
      AND artists.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM artists
      WHERE artists.id = products.artist_id
      AND artists.user_id = auth.uid()
    )
  );

CREATE POLICY "Artists can delete their own products"
  ON products FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM artists
      WHERE artists.id = products.artist_id
      AND artists.user_id = auth.uid()
    )
  );

-- Cart items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  quantity integer DEFAULT 1 CHECK (quantity > 0),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own cart"
  ON cart_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can add to their cart"
  ON cart_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their cart"
  ON cart_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete from their cart"
  ON cart_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  total_amount numeric NOT NULL CHECK (total_amount >= 0),
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'cancelled')),
  shipping_address jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  product_id uuid REFERENCES products(id) NOT NULL,
  artist_id uuid REFERENCES artists(id) NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  price_at_purchase numeric NOT NULL CHECK (price_at_purchase > 0),
  commission_rate numeric NOT NULL CHECK (commission_rate >= 0 AND commission_rate <= 100),
  commission_amount numeric NOT NULL CHECK (commission_amount >= 0),
  artist_amount numeric NOT NULL CHECK (artist_amount >= 0),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view items in their orders"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Artists can view their sold items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM artists
      WHERE artists.id = order_items.artist_id
      AND artists.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create order items"
  ON order_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

-- Commissions table
CREATE TABLE IF NOT EXISTS commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id uuid REFERENCES artists(id) ON DELETE CASCADE NOT NULL,
  order_item_id uuid REFERENCES order_items(id) ON DELETE CASCADE NOT NULL,
  amount numeric NOT NULL CHECK (amount >= 0),
  artist_amount numeric NOT NULL CHECK (artist_amount >= 0),
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'paid')),
  created_at timestamptz DEFAULT now(),
  paid_at timestamptz
);

ALTER TABLE commissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Artists can view their own commissions"
  ON commissions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM artists
      WHERE artists.id = commissions.artist_id
      AND artists.user_id = auth.uid()
    )
  );

CREATE POLICY "System can create commissions"
  ON commissions FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_artists_user_id ON artists(user_id);
CREATE INDEX IF NOT EXISTS idx_products_artist_id ON products(artist_id);
CREATE INDEX IF NOT EXISTS idx_products_is_active ON products(is_active);
CREATE INDEX IF NOT EXISTS idx_cart_items_user_id ON cart_items(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_artist_id ON order_items(artist_id);
CREATE INDEX IF NOT EXISTS idx_commissions_artist_id ON commissions(artist_id);