import { useState } from 'react';
import { X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Database } from '../lib/database.types';

type Artist = Database['public']['Tables']['artists']['Row'];
type Product = Database['public']['Tables']['products']['Row'];

interface ProductFormProps {
  artist: Artist;
  product: Product | null;
  onClose: () => void;
  onSuccess: () => void;
}

const CATEGORIES = ['Painting', 'Photography', 'Sculpture', 'Digital Art', 'Mixed Media', 'Illustration', 'Printmaking'];

export function ProductForm({ artist, product, onClose, onSuccess }: ProductFormProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    title: product?.title || '',
    description: product?.description || '',
    price: product?.price?.toString() || '',
    image_url: product?.image_url || '',
    category: product?.category || 'Painting',
    medium: product?.medium || '',
    dimensions: product?.dimensions || '',
    stock_quantity: product?.stock_quantity?.toString() || '1',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const payload = {
        artist_id: artist.id,
        title: formData.title,
        description: formData.description,
        price: parseFloat(formData.price),
        image_url: formData.image_url,
        category: formData.category,
        medium: formData.medium,
        dimensions: formData.dimensions,
        stock_quantity: parseInt(formData.stock_quantity),
      };

      if (product) {
        const { error } = await supabase
          .from('products')
          .update(payload)
          .eq('id', product.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('products')
          .insert(payload);
        if (error) throw error;
      }

      onSuccess();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const updateField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-lg relative my-8 fade-in">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-gray-400 hover:text-black transition-colors"
        >
          <X size={20} strokeWidth={1.5} />
        </button>

        <div className="p-8">
          <h2 className="font-serif text-2xl font-medium text-gray-900 mb-8">
            {product ? 'Edit Product' : 'New Product'}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">Title</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => updateField('title', e.target.value)}
                className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors"
                required
              />
            </div>

            <div>
              <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => updateField('description', e.target.value)}
                rows={3}
                className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">Price (USD)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => updateField('price', e.target.value)}
                  className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors"
                  required
                />
              </div>
              <div>
                <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">Stock</label>
                <input
                  type="number"
                  value={formData.stock_quantity}
                  onChange={(e) => updateField('stock_quantity', e.target.value)}
                  className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">Image URL</label>
              <input
                type="url"
                value={formData.image_url}
                onChange={(e) => updateField('image_url', e.target.value)}
                className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors"
                placeholder="https://..."
              />
            </div>

            <div>
              <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">Category</label>
              <select
                value={formData.category}
                onChange={(e) => updateField('category', e.target.value)}
                className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors bg-white"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">Medium</label>
                <input
                  type="text"
                  value={formData.medium}
                  onChange={(e) => updateField('medium', e.target.value)}
                  className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors"
                  placeholder="e.g., Oil on canvas"
                />
              </div>
              <div>
                <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">Dimensions</label>
                <input
                  type="text"
                  value={formData.dimensions}
                  onChange={(e) => updateField('dimensions', e.target.value)}
                  className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors"
                  placeholder="e.g., 24 x 36 in"
                />
              </div>
            </div>

            {error && (
              <p className="text-sm text-red-600 bg-red-50 px-4 py-3">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary py-4 disabled:opacity-50"
            >
              {loading ? 'Saving...' : product ? 'Update Product' : 'Create Product'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
