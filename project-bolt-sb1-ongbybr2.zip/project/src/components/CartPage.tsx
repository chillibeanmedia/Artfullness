import { Minus, Plus, X, ArrowRight, ArrowLeft, Heart } from 'lucide-react';
import { DUMMY_PRODUCTS } from '../data/dummyProducts';

interface CartPageProps {
  demoCart: Map<string, number>;
  onUpdateDemoCart: (productId: string, quantity: number) => void;
  onNavigate: (view: string) => void;
  onCheckout: () => void;
}

export function CartPage({ demoCart, onUpdateDemoCart, onNavigate, onCheckout }: CartPageProps) {
  const cartItems = Array.from(demoCart.entries()).map(([productId, quantity]) => {
    const product = DUMMY_PRODUCTS.find((p) => p.id === productId);
    return { productId, quantity, product };
  }).filter((item) => item.product);

  const subtotal = cartItems.reduce(
    (sum, item) => sum + (item.product?.price || 0) * item.quantity,
    0
  );

  const impactAmount = subtotal * 0.15;
  const shipping = subtotal >= 2000 ? 0 : 45;
  const total = subtotal + shipping;

  return (
    <div className="pt-[72px] min-h-screen bg-white">
      <div className="border-b border-gray-100">
        <div className="max-w-[1440px] mx-auto px-5 lg:px-10 py-12 lg:py-16">
          <button
            onClick={() => onNavigate('marketplace')}
            className="flex items-center space-x-2 text-sm text-gray-500 hover:text-black transition-colors mb-6"
          >
            <ArrowLeft size={16} />
            <span>Continue Shopping</span>
          </button>
          <h1 className="font-serif text-4xl lg:text-5xl font-medium text-gray-900">
            Your Cart
          </h1>
          {cartItems.length > 0 && (
            <p className="text-gray-500 text-base mt-2">
              {cartItems.length} item{cartItems.length !== 1 ? 's' : ''}
            </p>
          )}
        </div>
      </div>

      {cartItems.length === 0 ? (
        <div className="max-w-[1440px] mx-auto px-5 lg:px-10 py-24 text-center">
          <p className="font-serif text-2xl text-gray-300 mb-3">Your cart is empty</p>
          <p className="text-sm text-gray-400 mb-8">Discover artworks that speak to you</p>
          <button
            onClick={() => onNavigate('marketplace')}
            className="inline-flex items-center space-x-2 bg-black text-white px-10 py-4 text-[13px] font-medium tracking-wide hover:bg-gray-900 transition-colors"
          >
            <span>Browse Artworks</span>
            <ArrowRight size={16} />
          </button>
        </div>
      ) : (
        <div className="max-w-[1440px] mx-auto px-5 lg:px-10 py-10">
          <div className="grid lg:grid-cols-3 gap-16">
            <div className="lg:col-span-2">
              <div className="divide-y divide-gray-100">
                {cartItems.map((item) => (
                  <div key={item.productId} className="py-8 first:pt-0 last:pb-0">
                    <div className="flex space-x-6">
                      <button
                        onClick={() => onNavigate(`product:${item.productId}`)}
                        className="w-28 h-36 lg:w-36 lg:h-44 bg-gray-100 flex-shrink-0 overflow-hidden"
                      >
                        <img
                          src={item.product?.image_url}
                          alt={item.product?.title}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        />
                      </button>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div>
                            <button
                              onClick={() => onNavigate(`product:${item.productId}`)}
                              className="font-serif text-lg font-medium text-gray-900 hover:underline decoration-1 underline-offset-2"
                            >
                              {item.product?.title}
                            </button>
                            <p className="text-sm text-gray-500 mt-1">{item.product?.artist_name}</p>
                            <p className="text-[11px] text-gray-400 mt-1">
                              {item.product?.medium} | {item.product?.dimensions}
                            </p>
                            {item.product?.mental_health_focus && (
                              <div className="flex items-center space-x-1 mt-2">
                                <Heart size={12} className="text-gray-400" />
                                <span className="text-[11px] text-gray-400">
                                  Supporting {item.product.mental_health_focus}
                                </span>
                              </div>
                            )}
                          </div>
                          <button
                            onClick={() => onUpdateDemoCart(item.productId, 0)}
                            className="text-gray-300 hover:text-gray-600 transition-colors p-1"
                          >
                            <X size={18} />
                          </button>
                        </div>

                        <div className="flex items-center justify-between mt-6">
                          <div className="flex items-center space-x-4">
                            <button
                              onClick={() => onUpdateDemoCart(item.productId, item.quantity - 1)}
                              className="w-9 h-9 border border-gray-200 flex items-center justify-center hover:border-gray-400 transition-colors"
                            >
                              <Minus size={14} />
                            </button>
                            <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                            <button
                              onClick={() => onUpdateDemoCart(item.productId, item.quantity + 1)}
                              className="w-9 h-9 border border-gray-200 flex items-center justify-center hover:border-gray-400 transition-colors"
                            >
                              <Plus size={14} />
                            </button>
                          </div>
                          <p className="text-lg font-medium text-gray-900">
                            ${((item.product?.price || 0) * item.quantity).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="sticky top-[120px]">
                <div className="bg-gray-50 p-8">
                  <h2 className="font-serif text-xl font-medium text-gray-900 mb-6">Order Summary</h2>

                  <div className="space-y-4 mb-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Subtotal</span>
                      <span className="text-sm font-medium">${subtotal.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Shipping</span>
                      <span className="text-sm font-medium">
                        {shipping === 0 ? 'Free' : `$${shipping}`}
                      </span>
                    </div>
                    {shipping === 0 && (
                      <p className="text-[11px] text-green-600">Free shipping on orders over $2,000</p>
                    )}
                    <div className="border-t border-gray-200 pt-4 flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-900">Total</span>
                      <span className="text-lg font-medium text-gray-900">${total.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="bg-white p-4 mb-6">
                    <div className="flex items-center space-x-2 mb-2">
                      <Heart size={14} className="text-gray-500" />
                      <span className="text-[11px] text-gray-400 uppercase tracking-wider">Your Impact</span>
                    </div>
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">${impactAmount.toLocaleString()}</span> of this purchase
                      will fund mental health programs.
                    </p>
                  </div>

                  <button
                    onClick={onCheckout}
                    className="w-full bg-black text-white py-4 text-[13px] font-medium tracking-wide hover:bg-gray-900 transition-colors flex items-center justify-center space-x-2"
                  >
                    <span>Proceed to Checkout</span>
                    <ArrowRight size={16} />
                  </button>

                  <p className="text-[11px] text-gray-400 text-center mt-4">
                    Secure checkout. 85% goes to the artist, 15% to mental health.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
