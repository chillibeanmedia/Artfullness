import { useState, useMemo } from 'react';
import { SlidersHorizontal, X } from 'lucide-react';
import { DUMMY_PRODUCTS, CATEGORIES } from '../data/dummyProducts';
import { ProductCard } from './ProductCard';

interface MarketplaceProps {
  onAddToCart: (productId: string) => void;
  onNavigate: (view: string) => void;
  searchQuery?: string;
}

export function Marketplace({ onAddToCart, onNavigate, searchQuery = '' }: MarketplaceProps) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('newest');
  const [showFilters, setShowFilters] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);

  const filteredProducts = useMemo(() => {
    let results = [...DUMMY_PRODUCTS];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      results = results.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.artist_name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.medium.toLowerCase().includes(q) ||
          p.mental_health_focus.toLowerCase().includes(q)
      );
    }

    if (selectedCategory !== 'All') {
      results = results.filter((p) => p.category === selectedCategory);
    }

    results = results.filter((p) => p.price >= priceRange[0] && p.price <= priceRange[1]);

    switch (sortBy) {
      case 'price-asc':
        results.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        results.sort((a, b) => b.price - a.price);
        break;
      default:
        break;
    }

    return results;
  }, [selectedCategory, sortBy, searchQuery, priceRange]);

  return (
    <div className="pt-[72px] min-h-screen bg-white">
      <div className="border-b border-gray-100">
        <div className="max-w-[1440px] mx-auto px-5 lg:px-10 py-12 lg:py-16">
          <h1 className="font-serif text-4xl lg:text-5xl font-medium text-gray-900 mb-3">
            {searchQuery ? `Results for "${searchQuery}"` : 'Artworks'}
          </h1>
          <p className="text-gray-500 text-base max-w-xl">
            Original works by artists championing mental health awareness.
            Every purchase creates impact.
          </p>
        </div>
      </div>

      <div className="sticky top-[72px] z-30 bg-white border-b border-gray-100">
        <div className="max-w-[1440px] mx-auto px-5 lg:px-10">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center space-x-1 overflow-x-auto scrollbar-hide">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 text-[13px] font-medium tracking-wide whitespace-nowrap transition-colors ${
                    selectedCategory === cat
                      ? 'text-black border-b-2 border-black -mb-[1px]'
                      : 'text-gray-400 hover:text-gray-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="flex items-center space-x-4">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="text-[13px] text-gray-600 bg-transparent border-none outline-none cursor-pointer font-medium"
              >
                <option value="newest">Newest</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>

              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center space-x-1.5 text-[13px] text-gray-600 font-medium hover:text-black"
              >
                <SlidersHorizontal size={14} />
                <span>Filters</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {showFilters && (
        <div className="border-b border-gray-100 bg-gray-50">
          <div className="max-w-[1440px] mx-auto px-5 lg:px-10 py-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-900">Filters</h3>
              <button onClick={() => setShowFilters(false)} className="text-gray-400 hover:text-black">
                <X size={16} />
              </button>
            </div>
            <div className="flex items-center space-x-6">
              <div>
                <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">Price Range</label>
                <div className="flex items-center space-x-3">
                  <input
                    type="number"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
                    className="w-24 px-3 py-2 text-sm border border-gray-200 outline-none focus:border-gray-400"
                    placeholder="Min"
                  />
                  <span className="text-gray-300">--</span>
                  <input
                    type="number"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
                    className="w-24 px-3 py-2 text-sm border border-gray-200 outline-none focus:border-gray-400"
                    placeholder="Max"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-[1440px] mx-auto px-5 lg:px-10 py-10">
        <div className="flex items-center justify-between mb-8">
          <p className="text-sm text-gray-400">
            {filteredProducts.length} artwork{filteredProducts.length !== 1 ? 's' : ''}
          </p>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="text-center py-24">
            <p className="font-serif text-2xl text-gray-300 mb-2">No artworks found</p>
            <p className="text-sm text-gray-400">Try adjusting your search or filters</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={onAddToCart}
                onClick={() => onNavigate(`product:${product.id}`)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
