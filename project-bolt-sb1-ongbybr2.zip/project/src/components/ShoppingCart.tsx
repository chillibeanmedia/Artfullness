import { X, Minus, Plus, ArrowRight } from 'lucide-react';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Database } from '../lib/database.types';
import { useAuth } from '../contexts/AuthContext';
import { DUMMY_PRODUCTS, DummyProduct } from '../data/dummyProducts';

type CartItemDB = Database['public']['Tables']['cart_items']['Row'] & {
  products?: Database['public']['Tables']['products']['Row'];
};

interface CartDisplayItem {
  id: string;
  product_id: string;
  quantity: number;
  product: DummyProduct | null;
  isDemo: boolean;
}

interface ShoppingCartProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckout: (items: CartDisplayItem[]) => void;
  demoCart: Map<string, number>;
  onUpdateDemoCart: (productId: string, quantity: number) => void;
}

export function ShoppingCart({ isOpen, onClose, onCheckout, demoCart, onUpdateDemoCart }: ShoppingCartProps) {
  const { user } = useAuth();
  const [dbItems, setDbItems] = useState<CartItemDB[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && user) loadCart();
  }, [isOpen, user]);

  const loadCart = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('cart_items')
        .select('*, products(*)')
        .eq('user_id', user.id);
      if (error) throw error;
      setDbItems(data || []);
    } catch (e) {
      console.error('Error loading cart:', e);
    } finally {
      setLoading(false);
    }
  };

  const demoItems: CartDisplayItem[] = Array.from(demoCart.entries()).map(([productId, quantity]) => ({
    id: productId,
    product_id: productId,
    quantity,
    product: DUMMY_PRODUCTS.find((p) => p.id === productId) || null,
    isDemo: true,
  }));

  const allItems = [...demoItems];

  const subtotal = allItems.reduce(
    (sum, item) => sum + (item.product?.price || 0) * item.quantity,
    0
  );

  const updateQuantity = (item: CartDisplayItem, delta: number) => {
    const newQty = item.quantity + delta;
    if (item.isDemo) {
      onUpdateDemoCart(item.product_id, newQty);
    }
  };

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/30 z-40" onClick={onClose} />
      )}
      <div
        className={`fixed top-0 right-0 bottom-0 w-full max-w-[440px] bg-white z-50 shadow-2xl transform transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
            <h2 className="font-serif text-xl font-medium">Your Cart</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-black transition-colors">
              <X size={20} strokeWidth={1.5} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto">
            {allItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full px-6 text-center">
                <p className="font-serif text-xl text-gray-300 mb-2">Your cart is empty</p>
                <p className="text-sm text-gray-400 mb-6">Discover artworks that speak to you</p>
                <button onClick={onClose} className="btn-primary text-sm">
                  Continue Browsing
                </button>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {allItems.map((item) => (
                  <div key={item.id} className="px-6 py-5 flex space-x-4">
                    <div className="w-20 h-24 bg-gray-100 flex-shrink-0">
                      {item.product?.image_url && (
                        <img
                          src={item.product.image_url}
                          alt={item.product.title}
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-medium text-gray-900 truncate">
                        {item.product?.title}
                      </h3>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {item.product?.artist_name}
                      </p>
                      <p className="text-sm font-medium text-gray-900 mt-2">
                        ${item.product?.price.toLocaleString()}
                      </p>
                      <div className="flex items-center space-x-3 mt-3">
                        <button
                          onClick={() => updateQuantity(item, -1)}
                          className="w-7 h-7 border border-gray-200 flex items-center justify-center hover:border-gray-400 transition-colors"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="text-sm font-medium w-4 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item, 1)}
                          className="w-7 h-7 border border-gray-200 flex items-center justify-center hover:border-gray-400 transition-colors"
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {allItems.length > 0 && (
            <div className="border-t border-gray-100 px-6 py-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Subtotal</span>
                <span className="text-lg font-medium">${subtotal.toLocaleString()}</span>
              </div>
              <p className="text-[11px] text-gray-400">
                Shipping calculated at checkout. 15% supports mental health initiatives.
              </p>
              <button
                onClick={() => onCheckout(allItems)}
                className="w-full bg-black text-white py-4 text-sm font-medium tracking-wide hover:bg-gray-900 transition-colors flex items-center justify-center space-x-2"
              >
                <span>Checkout</span>
                <ArrowRight size={16} />
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
