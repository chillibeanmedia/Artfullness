import { ArrowLeft, Heart, ShoppingBag } from 'lucide-react';
import { DUMMY_PRODUCTS } from '../data/dummyProducts';
import { ProductCard } from './ProductCard';

interface ProductPageProps {
  productId: string;
  onNavigate: (view: string) => void;
  onAddToCart: (productId: string) => void;
}

export function ProductPage({ productId, onNavigate, onAddToCart }: ProductPageProps) {
  const product = DUMMY_PRODUCTS.find((p) => p.id === productId);

  if (!product) {
    return (
      <div className="pt-[72px] min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <p className="font-serif text-2xl text-gray-300 mb-3">Artwork not found</p>
          <button
            onClick={() => onNavigate('marketplace')}
            className="text-sm text-gray-500 hover:text-black underline"
          >
            Back to artworks
          </button>
        </div>
      </div>
    );
  }

  const relatedProducts = DUMMY_PRODUCTS
    .filter((p) => p.id !== product.id && (p.category === product.category || p.artist_name === product.artist_name))
    .slice(0, 4);

  const impactAmount = (product.price * 0.15).toLocaleString();

  return (
    <div className="pt-[72px] min-h-screen bg-white">
      <div className="max-w-[1440px] mx-auto px-5 lg:px-10 py-8">
        <button
          onClick={() => onNavigate('marketplace')}
          className="flex items-center space-x-2 text-sm text-gray-500 hover:text-black transition-colors mb-8"
        >
          <ArrowLeft size={16} />
          <span>All Artworks</span>
        </button>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          <div>
            <div className="aspect-[4/5] bg-gray-100 overflow-hidden">
              <img
                src={product.image_url}
                alt={product.title}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="lg:py-8">
            <div className="lg:sticky lg:top-[120px]">
              <p className="text-[11px] text-gray-400 uppercase tracking-[0.2em] mb-3">
                {product.category}
              </p>
              <h1 className="font-serif text-3xl lg:text-4xl font-medium text-gray-900 leading-snug mb-2">
                {product.title}
              </h1>
              <p className="text-base text-gray-500 mb-6">{product.artist_name}</p>

              <p className="font-serif text-3xl font-medium text-gray-900 mb-8">
                ${product.price.toLocaleString()}
              </p>

              <div className="flex space-x-4 mb-8">
                <button
                  onClick={() => onAddToCart(product.id)}
                  className="flex-1 bg-black text-white py-4 text-[13px] font-medium tracking-wide hover:bg-gray-900 transition-colors flex items-center justify-center space-x-2"
                >
                  <ShoppingBag size={16} />
                  <span>Add to Cart</span>
                </button>
                <button className="w-14 h-14 border border-gray-200 flex items-center justify-center hover:border-gray-400 transition-colors">
                  <Heart size={18} className="text-gray-500" />
                </button>
              </div>

              <div className="bg-gray-50 p-5 mb-8">
                <div className="flex items-center space-x-2 mb-2">
                  <Heart size={14} className="text-gray-500" />
                  <span className="text-[11px] text-gray-400 uppercase tracking-wider">Impact</span>
                </div>
                <p className="text-sm text-gray-600">
                  <span className="font-medium">${impactAmount}</span> of this purchase supports
                  {product.mental_health_focus ? ` ${product.mental_health_focus.toLowerCase()} initiatives` : ' mental health programs'}.
                </p>
              </div>

              <div className="border-t border-gray-100 pt-8 mb-8">
                <p className="text-[11px] text-gray-400 uppercase tracking-wider mb-4">Details</p>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-[11px] text-gray-400 mb-1">Medium</p>
                    <p className="text-sm text-gray-900">{product.medium}</p>
                  </div>
                  <div>
                    <p className="text-[11px] text-gray-400 mb-1">Dimensions</p>
                    <p className="text-sm text-gray-900">{product.dimensions}</p>
                  </div>
                  <div>
                    <p className="text-[11px] text-gray-400 mb-1">Year</p>
                    <p className="text-sm text-gray-900">{product.year}</p>
                  </div>
                  <div>
                    <p className="text-[11px] text-gray-400 mb-1">Availability</p>
                    <p className="text-sm text-gray-900">
                      {product.stock > 0 ? 'Available' : 'Sold Out'}
                    </p>
                  </div>
                </div>
              </div>

              {product.description && (
                <div className="border-t border-gray-100 pt-8 mb-8">
                  <p className="text-[11px] text-gray-400 uppercase tracking-wider mb-4">About This Work</p>
                  <p className="text-sm text-gray-600 leading-relaxed">{product.description}</p>
                </div>
              )}

              <div className="border-t border-gray-100 pt-8">
                <p className="text-[11px] text-gray-400 uppercase tracking-wider mb-4">About the Artist</p>
                <h3 className="text-base font-medium text-gray-900 mb-2">{product.artist_name}</h3>
                {product.artist_story && (
                  <p className="text-sm text-gray-500 leading-relaxed">{product.artist_story}</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {relatedProducts.length > 0 && (
          <div className="mt-20 mb-16 border-t border-gray-100 pt-16">
            <div className="flex items-end justify-between mb-10">
              <div>
                <p className="text-[11px] text-gray-400 uppercase tracking-[0.2em] mb-3">You May Also Like</p>
                <h2 className="font-serif text-2xl font-medium text-gray-900">Related Works</h2>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-10">
              {relatedProducts.map((related) => (
                <ProductCard
                  key={related.id}
                  product={related}
                  onAddToCart={onAddToCart}
                  onClick={() => onNavigate(`product:${related.id}`)}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
