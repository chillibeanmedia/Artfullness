import { DummyProduct } from '../data/dummyProducts';

interface ProductCardProps {
  product: DummyProduct;
  onAddToCart: (productId: string) => void;
  onClick: () => void;
  layout?: 'standard' | 'wide' | 'tall';
}

export function ProductCard({ product, onAddToCart, onClick, layout = 'standard' }: ProductCardProps) {
  const aspectClass = layout === 'tall'
    ? 'aspect-[3/4]'
    : layout === 'wide'
    ? 'aspect-[4/3]'
    : 'aspect-[3/4]';

  return (
    <div className="group cursor-pointer" onClick={onClick}>
      <div className={`art-card ${aspectClass} bg-gray-100 mb-3`}>
        <img
          src={product.image_url}
          alt={product.title}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="art-overlay" />
        <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart(product.id);
            }}
            className="w-full bg-white/95 backdrop-blur-sm text-black text-sm font-medium py-3 hover:bg-white transition-colors"
          >
            Add to Cart
          </button>
        </div>
      </div>
      <div className="space-y-1">
        <h3 className="text-sm font-medium text-gray-900 group-hover:underline decoration-1 underline-offset-2">
          {product.title}
        </h3>
        <p className="text-sm text-gray-500">{product.artist_name}</p>
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-gray-900">${product.price.toLocaleString()}</p>
          <span className="text-[11px] text-gray-400 bg-gray-100 px-2 py-0.5">
            {product.category}
          </span>
        </div>
        {product.mental_health_focus && (
          <p className="text-[11px] text-gray-400 tracking-wide">
            Supporting {product.mental_health_focus}
          </p>
        )}
      </div>
    </div>
  );
}
