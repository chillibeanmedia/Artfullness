import { useEffect, useState } from 'react';
import { Plus, CreditCard as Edit2, Trash2, DollarSign, Package, TrendingUp } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Database } from '../lib/database.types';
import { useAuth } from '../contexts/AuthContext';
import { ProductForm } from './ProductForm';

type Artist = Database['public']['Tables']['artists']['Row'];
type Product = Database['public']['Tables']['products']['Row'];

export function ArtistDashboard() {
  const [artist, setArtist] = useState<Artist | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    if (user) loadArtistData();
  }, [user]);

  const loadArtistData = async () => {
    if (!user) return;
    try {
      const { data: artistData } = await supabase
        .from('artists')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (artistData) {
        setArtist(artistData);
        const { data: productsData } = await supabase
          .from('products')
          .select('*')
          .eq('artist_id', artistData.id)
          .order('created_at', { ascending: false });
        setProducts(productsData || []);
      }
    } catch (error) {
      console.error('Error loading artist data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBecomeArtist = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    const formData = new FormData(e.currentTarget);
    try {
      const { data, error } = await supabase
        .from('artists')
        .insert({
          user_id: user.id,
          artist_name: formData.get('artistName') as string,
          story: formData.get('story') as string,
          mental_health_focus: formData.get('mentalHealthFocus') as string,
        })
        .select()
        .single();
      if (error) throw error;
      setArtist(data);
    } catch (error) {
      console.error('Error creating artist profile:', error);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    try {
      const { error } = await supabase.from('products').delete().eq('id', productId);
      if (error) throw error;
      setProducts(products.filter((p) => p.id !== productId));
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  if (loading) {
    return (
      <div className="pt-[72px] min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-gray-300 border-t-black rounded-full animate-spin" />
      </div>
    );
  }

  if (!artist) {
    return (
      <div className="pt-[72px] min-h-screen bg-white">
        <div className="max-w-xl mx-auto px-5 py-20">
          <p className="text-[11px] text-gray-400 uppercase tracking-[0.2em] mb-4">Get Started</p>
          <h1 className="font-serif text-4xl font-medium text-gray-900 mb-3">Become an Artist</h1>
          <p className="text-gray-500 mb-10">
            Create your artist profile and start selling your work while supporting mental health initiatives.
          </p>

          <form onSubmit={handleBecomeArtist} className="space-y-6">
            <div>
              <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">
                Artist Name
              </label>
              <input
                type="text"
                name="artistName"
                required
                className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors"
              />
            </div>

            <div>
              <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">
                Your Story
              </label>
              <textarea
                name="story"
                rows={4}
                className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors resize-none"
                placeholder="Share your journey as an artist and what drives your work..."
              />
            </div>

            <div>
              <label className="text-[11px] text-gray-400 uppercase tracking-wider block mb-2">
                Mental Health Focus
              </label>
              <input
                type="text"
                name="mentalHealthFocus"
                className="w-full px-4 py-3 text-sm border border-gray-200 outline-none focus:border-black transition-colors"
                placeholder="e.g., Anxiety Awareness, Depression Support"
              />
            </div>

            <button type="submit" className="w-full btn-primary py-4">
              Create Artist Profile
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-[72px] min-h-screen bg-white">
      <div className="border-b border-gray-100">
        <div className="max-w-[1440px] mx-auto px-5 lg:px-10 py-10">
          <p className="text-[11px] text-gray-400 uppercase tracking-[0.2em] mb-3">Dashboard</p>
          <h1 className="font-serif text-3xl lg:text-4xl font-medium text-gray-900">
            {artist.artist_name}
          </h1>
        </div>
      </div>

      <div className="max-w-[1440px] mx-auto px-5 lg:px-10 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-[11px] text-gray-400 uppercase tracking-wider">Total Sales</p>
              <DollarSign size={16} className="text-gray-300" />
            </div>
            <p className="font-serif text-3xl font-medium text-gray-900">
              ${artist.total_sales.toFixed(2)}
            </p>
          </div>

          <div className="border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-[11px] text-gray-400 uppercase tracking-wider">Products</p>
              <Package size={16} className="text-gray-300" />
            </div>
            <p className="font-serif text-3xl font-medium text-gray-900">{products.length}</p>
          </div>

          <div className="border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-[11px] text-gray-400 uppercase tracking-wider">Commission</p>
              <TrendingUp size={16} className="text-gray-300" />
            </div>
            <p className="font-serif text-3xl font-medium text-gray-900">{artist.commission_rate}%</p>
            <p className="text-xs text-gray-400 mt-1">You keep {100 - artist.commission_rate}%</p>
          </div>
        </div>

        <div className="flex items-center justify-between mb-8">
          <h2 className="font-serif text-2xl font-medium text-gray-900">Your Products</h2>
          <button
            onClick={() => setShowProductForm(true)}
            className="btn-primary text-sm flex items-center space-x-2"
          >
            <Plus size={16} />
            <span>Add Product</span>
          </button>
        </div>

        {products.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-gray-200">
            <Package size={32} className="text-gray-300 mx-auto mb-4" />
            <p className="text-gray-400 mb-4">No products listed yet</p>
            <button
              onClick={() => setShowProductForm(true)}
              className="text-sm font-medium text-black hover:underline"
            >
              Create your first listing
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <div key={product.id} className="group">
                <div className="aspect-[3/4] bg-gray-100 mb-3 overflow-hidden relative">
                  <img
                    src={product.image_url || 'https://images.pexels.com/photos/1839919/pexels-photo-1839919.jpeg?auto=compress&cs=tinysrgb&w=400'}
                    alt={product.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-200 flex space-x-2">
                    <button
                      onClick={() => { setEditingProduct(product); setShowProductForm(true); }}
                      className="flex-1 bg-white text-black py-2 text-xs font-medium hover:bg-gray-100 flex items-center justify-center space-x-1"
                    >
                      <Edit2 size={12} />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => handleDeleteProduct(product.id)}
                      className="flex-1 bg-white text-red-600 py-2 text-xs font-medium hover:bg-red-50 flex items-center justify-center space-x-1"
                    >
                      <Trash2 size={12} />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
                <h3 className="text-sm font-medium text-gray-900">{product.title}</h3>
                <p className="text-sm text-gray-900 mt-1">${product.price.toFixed(2)}</p>
                <p className="text-xs text-gray-400 mt-0.5">Stock: {product.stock_quantity}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {showProductForm && (
        <ProductForm
          artist={artist}
          product={editingProduct}
          onClose={() => { setShowProductForm(false); setEditingProduct(null); }}
          onSuccess={() => { loadArtistData(); setShowProductForm(false); setEditingProduct(null); }}
        />
      )}
    </div>
  );
}
